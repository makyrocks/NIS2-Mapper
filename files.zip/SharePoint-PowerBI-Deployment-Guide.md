# NIS2 Compliance Mapper - SharePoint & Power BI Deployment Guide
## Developed by Mayank Singh

---

## 📋 Table of Contents
1. [Quick Overview](#quick-overview)
2. [Option 1: SharePoint Modern Page (Recommended)](#option-1-sharepoint-modern-page-recommended)
3. [Option 2: SharePoint + Power Apps + Power BI (Enterprise)](#option-2-sharepoint--power-apps--power-bi-enterprise)
4. [Option 3: Simple File Upload](#option-3-simple-file-upload)
5. [Power BI Dashboard Integration](#power-bi-dashboard-integration)
6. [Complete Setup Instructions](#complete-setup-instructions)

---

## Quick Overview

### ✅ What Works Where:

| Component | SharePoint | Power BI | Power Apps |
|-----------|------------|----------|------------|
| Host HTML Tool | ✅ Yes | ❌ No | ❌ No |
| Store Evidence | ✅ Yes | ❌ No | ✅ Yes |
| Compliance Tracking | ✅ Yes | ✅ Yes (Reporting) | ✅ Yes |
| Interactive Forms | ✅ Yes | ❌ Limited | ✅ Yes |
| Executive Dashboards | ❌ Limited | ✅ Yes | ❌ No |
| Mobile Access | ✅ Yes | ✅ Yes | ✅ Yes |

### 🎯 Recommended Architecture:
```
SharePoint Site (Main Hub)
├── HTML Tool (Embedded on page)
├── Document Libraries (Evidence storage)
├── Lists (Compliance tracking data)
│
├── Power Apps (Mobile forms)
│
├── Power Automate (Workflows & alerts)
│
└── Power BI (Executive dashboards)
```

---

## Option 1: SharePoint Modern Page (Recommended)

**Best for:** Most organizations, easiest setup, no coding required

### Step-by-Step Instructions:

#### 1. Create SharePoint Site
```
1. Go to SharePoint Home
2. Click "+ Create site"
3. Choose "Team site"
4. Name: "NIS2 Compliance Hub"
5. Description: "NIS2 Directive (EU) 2022/2555 Compliance Management"
6. Privacy: Private (recommended) or Public
7. Click "Finish"
```

#### 2. Upload HTML File
```
1. In your site, click "Documents"
2. Click "Upload" > "Files"
3. Upload: nis2-compliance-mapper.html
4. Right-click file > "Details"
5. Copy the file URL (you'll need this)
```

#### 3. Create Modern Page
```
1. Click "New" > "Page"
2. Choose "Blank" template
3. Page name: "NIS2 Compliance Tracker"
4. Add web part: "Embed"
5. Paste the SharePoint file URL
6. Adjust height: 1200px minimum
7. Click "Publish"
```

#### 4. Set as Home Page (Optional)
```
1. Click settings gear icon
2. "Site information"
3. "View all site settings"
4. Under "Look and Feel" > "Welcome Page"
5. Set your new page as home
```

### ⚠️ Important Notes:
- The HTML file will work immediately
- All data saves to browser localStorage
- Evidence "uploads" are simulated (text only)
- For real file uploads, see Option 2

---

## Option 2: SharePoint + Power Apps + Power BI (Enterprise)

**Best for:** Large organizations, real evidence management, executive reporting

### Architecture Overview:
```
1. SharePoint Lists (Data Storage)
2. Document Libraries (Evidence Files)
3. Power Apps (Data Entry & Mobile)
4. Power Automate (Workflows)
5. Power BI (Executive Dashboard)
6. HTML Tool (Embedded viewer)
```

### Detailed Setup:

#### Part A: SharePoint Lists Structure

**List 1: NIS2_Requirements**
```
Columns:
- Title (Single line text) - e.g., "Art. 21(2)(a)"
- Requirement_Title (Single line text)
- Description (Multiple lines)
- Compliance_Status (Choice: Compliant, Partial, Non-Compliant)
- Penalty_Level (Choice: Critical, High, Medium)
- ISO_27001_Controls (Multiple lines)
- NIST_CSF_Functions (Multiple lines)
- CIS_Controls (Multiple lines)
- CSA_CCM_Controls (Multiple lines)
- Evidence_Count (Number)
- Owner (Person)
- Last_Updated (Date)
- Comments (Multiple lines)
```

**List 2: Evidence_Documents**
```
Columns:
- Title (Single line text) - Document name
- NIS2_Article (Lookup to NIS2_Requirements)
- Document_Link (Hyperlink) - Link to actual file
- Upload_Date (Date)
- Uploaded_By (Person)
- Document_Type (Choice: Policy, Procedure, Certificate, Report, etc.)
- Expiry_Date (Date)
- Status (Choice: Valid, Expired, Under Review)
```

**List 3: Compliance_Projects**
```
Columns:
- Title (Single line text) - Project name
- Created_Date (Date)
- Owner (Person)
- Overall_Compliance_Rate (Number)
- Last_Updated (Date)
- Status (Choice: Active, Archived)
```

#### Part B: Document Library Structure

**Create these libraries:**
```
📁 NIS2_Evidence
   ├── 📁 Art_20_Governance
   ├── 📁 Art_21_Risk_Management
   ├── 📁 Art_21_2a_Policies
   ├── 📁 Art_21_2b_Incident_Handling
   ├── 📁 Art_21_2c_Business_Continuity
   ├── 📁 Art_21_2d_Supply_Chain
   ├── 📁 Art_21_2e_Network_Security
   ├── 📁 Art_21_2f_Physical_Security
   ├── 📁 Art_21_2g_Cyber_Hygiene
   ├── 📁 Art_21_2h_HR_Security
   ├── 📁 Art_21_2i_Encryption_MFA
   ├── 📁 Art_21_2j_Threat_Intelligence
   └── 📁 Art_23_Incident_Reporting
```

**Metadata columns for library:**
```
- NIS2_Article (Managed metadata)
- Compliance_Status (Choice)
- Document_Type (Choice)
- Owner (Person)
- Review_Date (Date)
- Related_Standard (Choice: ISO 27001, NIST, CIS, CSA)
```

#### Part C: Power Apps Canvas App

**Create a Power Apps app:**
```
1. Go to make.powerapps.com
2. Create Canvas app from blank
3. Connect to SharePoint lists
4. Build screens:
   - Home Dashboard
   - Requirements List
   - Requirement Details
   - Evidence Upload
   - Compliance Report

5. Add galleries for each NIS2 requirement
6. Add forms for data entry
7. Add buttons to upload to document library
8. Publish app
```

**Sample Power Apps Formulas:**
```powerapps
// Get compliance rate
CountRows(Filter(NIS2_Requirements, Compliance_Status = "Compliant")) / 
CountRows(NIS2_Requirements) * 100

// Filter non-compliant
Filter(NIS2_Requirements, Compliance_Status = "Non-Compliant")

// Upload to SharePoint library
Patch(
    NIS2_Evidence,
    Defaults(NIS2_Evidence),
    {
        Title: UploadFileName,
        File: UploadedFile,
        NIS2_Article: SelectedArticle,
        Uploaded_By: User().FullName
    }
)
```

#### Part D: Power Automate Workflows

**Flow 1: Alert on Non-Compliance**
```
Trigger: When an item is modified in NIS2_Requirements
Condition: If Compliance_Status = "Non-Compliant"
Action: Send email to Owner and Security Team
```

**Flow 2: Evidence Expiry Reminder**
```
Trigger: Recurrence (Daily)
Condition: If Expiry_Date within 30 days
Action: Send reminder email
```

**Flow 3: Weekly Compliance Report**
```
Trigger: Recurrence (Weekly - Monday 9 AM)
Action: 
  - Get all requirements
  - Calculate compliance rate
  - Generate HTML report
  - Send to Management
```

**Flow 4: Incident Reporting Escalation**
```
Trigger: When "Art. 23" status changes to Non-Compliant
Action:
  - Immediate alert to CISO
  - Create urgent task in Planner
  - Log in incident register
```

#### Part E: Power BI Dashboard

**Create Power BI Report:**

**Data Sources:**
```
1. Connect to SharePoint Lists:
   - NIS2_Requirements
   - Evidence_Documents
   - Compliance_Projects
```

**Visuals to Create:**
```
1. Compliance Overview (Donut Chart)
   - Compliant vs Partial vs Non-Compliant

2. Compliance by Article (Bar Chart)
   - X-axis: NIS2 Articles
   - Y-axis: Compliance Status

3. Compliance Trend (Line Chart)
   - X-axis: Date
   - Y-axis: Compliance %

4. Evidence Coverage (Gauge)
   - Requirements with evidence / Total requirements

5. Critical Non-Compliance (Table)
   - Articles marked as Non-Compliant + Critical penalty

6. Evidence by Type (Pie Chart)
   - Policy, Procedure, Certificate, etc.

7. Owner Accountability (Matrix)
   - Owners vs Compliance Status

8. Standards Coverage (Stacked Bar)
   - ISO 27001, NIST, CIS, CSA coverage
```

**DAX Measures:**
```dax
Compliance Rate = 
DIVIDE(
    COUNTROWS(FILTER(NIS2_Requirements, [Compliance_Status] = "Compliant")),
    COUNTROWS(NIS2_Requirements)
) * 100

Critical Non-Compliant = 
CALCULATE(
    COUNTROWS(NIS2_Requirements),
    NIS2_Requirements[Compliance_Status] = "Non-Compliant",
    NIS2_Requirements[Penalty_Level] = "Critical"
)

Evidence Coverage = 
DIVIDE(
    COUNTROWS(FILTER(NIS2_Requirements, [Evidence_Count] > 0)),
    COUNTROWS(NIS2_Requirements)
) * 100
```

**Publish Dashboard:**
```
1. Click "Publish"
2. Choose workspace
3. Embed in SharePoint:
   - SharePoint page > Add web part > Power BI
   - Select your report
   - Set permissions
```

---

## Option 3: Simple File Upload

**Best for:** Quick start, testing, small teams

### Instructions:
```
1. Go to your SharePoint site
2. Click "Documents"
3. Upload: nis2-compliance-mapper.html
4. Click the file to open
5. Share link with team

Limitations:
- Data stored in browser only
- No real file uploads
- Limited collaboration
- Not recommended for production
```

---

## Power BI Dashboard Integration

### Creating Executive Dashboard

**Dashboard Sections:**

**1. Executive Summary**
```
- Overall compliance rate (Large KPI)
- Critical issues count (Red alert)
- Trend line (Last 6 months)
- Next review date
```

**2. NIS2 Article Status**
```
- Matrix visual showing all 13 requirements
- Color coding: Red/Yellow/Green
- Click to drill into details
```

**3. Evidence Management**
```
- Total evidence documents
- Documents by type
- Expired documents alert
- Upload activity timeline
```

**4. Standards Coverage**
```
- ISO 27001 coverage %
- NIST CSF coverage %
- CIS Controls coverage %
- CSA CCM coverage %
```

**5. Ownership & Accountability**
```
- Table: Owner | Assigned Requirements | Compliance Rate
- Highlight non-compliant owners
```

**6. Penalty Risk Analysis**
```
- Critical penalty items (immediate action)
- High penalty items (action needed)
- Financial exposure estimate
```

### Embedding in SharePoint:
```
1. Publish Power BI report to workspace
2. Get embed link
3. SharePoint page > Embed web part
4. Paste Power BI link
5. Configure size and permissions
```

---

## Complete Setup Instructions

### Phase 1: Foundation (Week 1)
```
□ Create SharePoint site
□ Upload HTML tool
□ Create basic page with embedded tool
□ Set up document library structure
□ Define permissions (Security team, Management, Auditors)
```

### Phase 2: Data Structure (Week 2)
```
□ Create SharePoint lists
□ Populate NIS2 requirements list
□ Set up metadata columns
□ Configure views (by status, by owner, by penalty)
□ Create initial evidence folders
```

### Phase 3: Automation (Week 3)
```
□ Build Power Automate flows
  - Non-compliance alerts
  - Evidence expiry reminders
  - Weekly reports
  - Incident escalation
□ Test all workflows
□ Train security team
```

### Phase 4: Reporting (Week 4)
```
□ Build Power BI dashboard
□ Create executive report
□ Embed in SharePoint
□ Set up scheduled refresh
□ Present to management
```

### Phase 5: Power Apps (Optional - Week 5)
```
□ Build canvas app
□ Design mobile-friendly interface
□ Connect to SharePoint lists
□ Add offline capability
□ Publish to Teams
```

---

## Best Practices

### Security & Permissions:
```
SharePoint Site:
├── Site Owners: CISO, IT Director
├── Site Members: Security Team, Compliance Team
└── Site Visitors: Auditors (read-only)

Document Library:
├── Full Control: Security Team
├── Edit: Document owners
└── Read: Management, Auditors

Power BI Dashboard:
├── Admin: CISO
├── Member: Management
└── Viewer: Board members
```

### Maintenance:
```
Daily:
- Check non-compliance alerts
- Review new evidence uploads

Weekly:
- Compliance status review
- Update requirements as needed

Monthly:
- Management review meeting
- Evidence expiry check
- Audit preparation

Quarterly:
- Full compliance assessment
- Update documentation
- Board presentation
```

### Backup & Recovery:
```
1. Enable versioning on document libraries
2. Set up retention policies (7 years for audit)
3. Export compliance data monthly
4. Keep JSON backups from HTML tool
5. Document restoration procedures
```

---

## Troubleshooting

### Common Issues:

**HTML tool not loading in SharePoint:**
```
Solution:
1. Check if scripts are enabled
2. Try different web part (Script Editor vs Embed)
3. Verify file URL is accessible
4. Check browser console for errors
```

**Power BI not refreshing:**
```
Solution:
1. Check gateway connection
2. Verify SharePoint permissions
3. Set up scheduled refresh
4. Use DirectQuery if needed
```

**Power Apps connection errors:**
```
Solution:
1. Re-authenticate SharePoint connector
2. Check list/library permissions
3. Verify column names match formulas
4. Test in app preview mode
```

**Power Automate flow failures:**
```
Solution:
1. Check trigger conditions
2. Verify SharePoint permissions
3. Test with sample data
4. Review flow run history
5. Enable verbose logging
```

---

## Cost Considerations

### Licensing Requirements:

**SharePoint:**
- Included in Microsoft 365 E3/E5
- SharePoint Online Plan 1/2

**Power Apps:**
- Power Apps per user plan ($20/user/month)
- Or included in Microsoft 365 E5

**Power BI:**
- Power BI Pro ($9.99/user/month) - For creators
- Power BI Premium ($4,995/month) - For large deployments
- Or included in Microsoft 365 E5

**Power Automate:**
- Power Automate per user ($15/user/month)
- Or included in Microsoft 365 E3/E5

**Recommended Packages:**
- Small Team (< 10 users): Microsoft 365 E3
- Enterprise: Microsoft 365 E5 (includes everything)

---

## Additional Resources

**Microsoft Documentation:**
- SharePoint: https://docs.microsoft.com/sharepoint
- Power Apps: https://docs.microsoft.com/powerapps
- Power Automate: https://docs.microsoft.com/power-automate
- Power BI: https://docs.microsoft.com/power-bi

**Training:**
- Microsoft Learn (Free): https://learn.microsoft.com
- Power Platform YouTube: https://youtube.com/PowerPlatform

**Community:**
- Power Apps Community: https://powerusers.microsoft.com/t5/Power-Apps-Community/ct-p/PowerApps1
- Power BI Community: https://community.powerbi.com

---

## Support

**Created by:** Mayank Singh
**Version:** 1.0
**Last Updated:** November 2024

For questions about this deployment guide, please contact your Microsoft 365 administrator or IT support team.

---

## Quick Reference Commands

### PowerShell - Bulk Upload to SharePoint:
```powershell
# Connect to SharePoint
Connect-PnPOnline -Url "https://yourtenant.sharepoint.com/sites/NIS2Compliance" -Interactive

# Upload file
Add-PnPFile -Path "nis2-compliance-mapper.html" -Folder "SitePages"

# Create document library
New-PnPList -Title "NIS2_Evidence" -Template DocumentLibrary

# Add metadata column
Add-PnPField -List "NIS2_Evidence" -DisplayName "NIS2_Article" -InternalName "NIS2Article" -Type Choice -Choices "Art. 20","Art. 21(2)(a)","Art. 21(2)(b)"
```

### Power Automate - Get Compliance Rate:
```
length(filter(body('Get_items')?['value'], equals(item()?['Compliance_Status'], 'Compliant'))) 
/ 
length(body('Get_items')?['value']) 
* 100
```

### Power BI - Connect to SharePoint:
```
1. Get Data > More > SharePoint Online List
2. Enter site URL: https://yourtenant.sharepoint.com/sites/NIS2Compliance
3. Select lists: NIS2_Requirements, Evidence_Documents
4. Load data
```

---

**END OF GUIDE**
